var selectedRow = null;

//Alertas
function showAlert(message, className){
    const div = document.createElement("div");
    div.className = 'alert alert-${className}';

    div.appendChild(document.createTextNode(message));
    const container = document.querySelector(".container");
    const main = document.querySelector(".main")
    container.insertBefore(div, main);

    setTimeout(() => document.querySelector(".alert").remove(), 3000);
}

//clear all fields
function clearFields(){
    document.querySelector("#")
}






//Eliminacion de datos
document.querySelector("#student-list").addEventListener("click", (e) =>{
    target = e.target;
    //Si el usuario da en el boton de elimiar se elimina el usuario y marca una alerta de el proceso
    if(target.classList.contains("delete")){
        target.parentElement.parentElement.remove();
        showAlert("Usuario eliminado");
    }
});