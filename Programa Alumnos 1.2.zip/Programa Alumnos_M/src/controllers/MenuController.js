function alta(req, res) {
    res.render('Menu/menu');
}

//Exportacion de nuestras funciones 
module.exports = {
    alta: alta,
  }